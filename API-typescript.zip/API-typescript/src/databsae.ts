//Importar a biblioteca do Mysql/promisse para estabelecer a conexão com o banco de dados
import mysql from "mysql2/promise"
import { describe } from "node:test"

//A constate pool é uma conexão com o banco de dados.
//Com ela iremos criar uma conexão com o mysql passando alguns parâmetros,tais como: 
// -Host(Local onde está o banco de dados)
// -User(Usuario do banco de dados)
// -Password(Senha para acesso ao banco de dados)
// - DataBase (Nome do banco de dados)
// - Port(Porta de Comunicação do banco de dados)
const pool = mysql.createPool({
   host:"127.0.0.1",
   user:"root",
   password:"",
   database:"dbts",
   port:3306
})
export default pool;